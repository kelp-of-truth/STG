const canvas=document.getElementById("canvas");

let timer=0;

let danmaku=[
];
// danmaku.push(["0",0,0,0,0])
function tick(){

    if(timer%3===0){
        for(let i=0;i<12;i++){
            danmaku.push(["0",270,240,i*30+(Math.floor(Math.random()*6)),5]);
        }
    }


    const ctx=canvas.getContext("2d");
    ctx.clearRect(0,0,540,480);
    ctx.fillStyle="#000"
    ctx.fillRect(0,0,540,480);
    var screenout=[];
    for(let i=0;i<danmaku.length;i++){
        ctx.fillStyle="#fff";
        var idx=danmaku[i];
        idx[1]+=cos[idx[3]+360]*idx[4];
        idx[2]-=sin[idx[3]+360]*idx[4];
        if(idx[1]<-10||idx[1]>580){screenout.push(i)}
        else if(idx[2]<-10||idx[2]>520){screenout.push(i)}
        ctx.fillRect(idx[1]-4,idx[2]-8,8,4);
        ctx.fillRect(idx[1]-8,idx[2]-4,4,8);
        ctx.fillRect(idx[1]+4,idx[2]-4,4,8);
        ctx.fillRect(idx[1]-4,idx[2]+4,8,4);
    }
    for(let i=0;i<screenout.length;i++){
        danmaku.splice(screenout[i]-i,1);
    }

    timer++;

    requestAnimationFrame(tick);
};

const pi=Math.PI;
let sin=[];
let cos=[];
for(let i=0;i<1080;i++){
    sin.push(Math.sin(pi*((i-360)/180)));
    cos.push(Math.cos(pi*((i-360)/180)));
    if(i===1079){
        tick();
    }
}
