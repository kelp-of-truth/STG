const canvas=document.getElementById("canvas");

let timer=0;
let splites=[
    "star-blue"
]
for(let i=0;i<splites.length;i++){
    var val=splites[i];
    splites[i]=new Image();
    splites[i].src=`./${val}.png`;
}
let danmaku=[
];
setInterval(() => {
    var random=Math.floor(Math.random()*5);
    for(let i=0;i<72;i++){
        danmaku.push([0,262,100,`idx[1]+(idx[0]<20?cos[${random+i*5}]*(4-idx[0]/20):2*cos[${random+i*5+90}])`,`idx[2]+(idx[0]<20?sin[${random+i*5}]*(4-idx[0]/20):2*sin[${random+i*5+90}])`]);
        danmaku.push([0,262,100,`idx[1]+(idx[0]<20?cos[${random+i*5}]*(4-idx[0]/20):2*cos[${random+i*5+360+-90}])`,`idx[2]+(idx[0]<20?sin[${random+i*5}]*(4-idx[0]/20):2*sin[${random+i*5+360-90}])`]);
    }
}, 500);
function tick(){
    const ctx=canvas.getContext("2d");
    ctx.clearRect(0,0,540,480);
    ctx.fillStyle="#000"
    ctx.fillRect(0,0,540,480);
    var screenout=[];
    for(let i=0;i<danmaku.length;i++){
        ctx.fillStyle="#fff";
        var idx=danmaku[i];
        // idx[1]=eval(idx[4]);
        // idx[2]=eval(idx[5]);
        idx[1]=eval(idx[3]);
        idx[2]=eval(idx[4]);
        if(idx[1]<-40||idx[1]>580){screenout.push(i)}
        else if(idx[2]<-40||idx[2]>520){screenout.push(i)}
        ctx.drawImage(splites[0],idx[1]+4,idx[2]+4)
        // ctx.fillRect(idx[1]-4,idx[2]-8,8,4);
        // ctx.fillRect(idx[1]-8,idx[2]-4,4,8);
        // ctx.fillRect(idx[1]+4,idx[2]-4,4,8);
        // ctx.fillRect(idx[1]-4,idx[2]+4,8,4);
        idx[0]++;
    }
    for(let i=0;i<screenout.length;i++){
        danmaku.splice(screenout[i]-i,1);
    }

    timer++;

    requestAnimationFrame(tick);
};

const pi=Math.PI;
let sin=[];
let cos=[];
for(let i=0;i<1080;i++){
    sin.push(Math.sin(pi*((i-360)/180)));
    cos.push(Math.cos(pi*((i-360)/180)));
    if(i===1079){
        tick();
    }
}
